# 🎮 CTF Quiz Challenge

A mobile CTF (Capture The Flag) challenge in the form of a quiz game for Android.

## 🎯 Challenge Description

This is a quiz application with 100 CTF-related questions across 10 categories. Players need to:

1. **Install the APK** on their Android device
2. **Play the quiz game** and answer questions
3. **Find the hidden flag** by reverse engineering the APK
4. **Submit the flag** in the format: `ICSSC{...}`

## 🚀 Getting Started

### Option 1: Download Pre-built APK
- Go to the **Actions** tab
- Click on the latest successful build
- Download the APK from **Artifacts**

### Option 2: Build from Source
```bash
git clone https://github.com/mudasser7122918-dev/mobile_ctf.git
cd mobile_ctf
./gradlew assembleDebug
```

## 🔍 Flag Location

The flag is hidden somewhere in the source code. You'll need to:
- Decompile the APK
- Analyze the source code
- Find the hidden flag

**Hint:** Look for obfuscated or encoded strings in the codebase.

## 🛠️ Technical Details

- **Platform:** Android (API 21+)
- **Language:** Kotlin
- **Build System:** Gradle
- **UI Framework:** Material Design

## 📱 Features

- 100 CTF quiz questions
- 10 different categories
- Timer and scoring system
- Modern Material Design UI
- Hidden flag for reverse engineering

## 🎯 Categories

1. **Web Security**
2. **Cryptography**
3. **Reverse Engineering**
4. **Forensics**
5. **Network Security**
6. **Binary Exploitation**
7. **Mobile Security**
8. **OSINT**
9. **Steganography**
10. **Miscellaneous**

## 🏆 Scoring

- Correct answer: +10 points
- Wrong answer: -5 points
- Time bonus: +1 point per second remaining

## 🔧 Development

Built with:
- Android Studio / IntelliJ IDEA
- Kotlin
- Material Design Components
- Gradle Build System

## 📄 License

This project is for educational purposes only. Use responsibly in CTF competitions.

---

**Good luck finding the flag! 🚩**
