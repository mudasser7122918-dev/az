package com.ctf.quizchallenge

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataAdapter(private val flags: List<FlagItem>) : RecyclerView.Adapter<DataAdapter.DataViewHolder>() {
    
    class DataViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flagText: TextView = itemView.findViewById(R.id.flagText)
        val categoryText: TextView = itemView.findViewById(R.id.categoryText)
        val descriptionText: TextView = itemView.findViewById(R.id.descriptionText)
        val statusText: TextView = itemView.findViewById(R.id.statusText)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_data, parent, false)
        return DataViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: DataViewHolder, position: Int) {
        val flag = flags[position]
        
        holder.flagText.text = flag.flag
        holder.categoryText.text = flag.category
        holder.descriptionText.text = flag.description
        
        if (flag.isCollected) {
            holder.statusText.text = "✅ COLLECTED"
            holder.statusText.setTextColor(holder.itemView.context.getColor(android.R.color.holo_green_dark))
        } else {
            holder.statusText.text = "❌ NOT FOUND"
            holder.statusText.setTextColor(holder.itemView.context.getColor(android.R.color.holo_red_dark))
        }
    }
    
    override fun getItemCount(): Int = flags.size
}

