package com.ctf.quizchallenge

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager

class MainActivity : AppCompatActivity() {
    
    private lateinit var startQuizButton: Button
    private lateinit var settingsButton: Button
    private lateinit var flagsButton: Button
    private lateinit var highScoreText: TextView
    private lateinit var totalQuestionsText: TextView
    private lateinit var flagsCollectedText: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initializeViews()
        setupClickListeners()
        updateStats()
    }
    
    private fun initializeViews() {
        startQuizButton = findViewById(R.id.startQuizButton)
        settingsButton = findViewById(R.id.settingsButton)
        flagsButton = findViewById(R.id.flagsButton)
        highScoreText = findViewById(R.id.highScoreText)
        totalQuestionsText = findViewById(R.id.totalQuestionsText)
        flagsCollectedText = findViewById(R.id.flagsCollectedText)
    }
    
    private fun setupClickListeners() {
        startQuizButton.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            startActivity(intent)
        }
        
        settingsButton.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
        
        flagsButton.setOnClickListener {
            val intent = Intent(this, AnalyticsActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun updateStats() {
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val highScore = prefs.getInt("high_score", 0)
        val totalQuestions = QuizData.generateAllQuestions().size
        
        val databaseHelper = DatabaseHelper(this)
        val flagsCollected = databaseHelper.getFlagCount()
        val totalFlags = databaseHelper.getTotalFlagCount()
        
        highScoreText.text = "High Score: $highScore"
        totalQuestionsText.text = "Total Questions: $totalQuestions"
        flagsCollectedText.text = "Flags Collected: $flagsCollected / $totalFlags"
    }
    
    override fun onResume() {
        super.onResume()
        updateStats()
    }
}
