package com.ctf.quizchallenge

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager

class QuizActivity : AppCompatActivity() {
    
    private lateinit var questionText: TextView
    private lateinit var questionNumberText: TextView
    private lateinit var scoreText: TextView
    private lateinit var timerText: TextView
    private lateinit var categoryText: TextView
    private lateinit var difficultyText: TextView
    private lateinit var hintButton: Button
    private lateinit var optionButtons: List<Button>
    private lateinit var progressBar: ProgressBar
    
    private var currentQuestionIndex = 0
    private var score = 0
    private var questions: List<Question> = emptyList()
    private var timer: CountDownTimer? = null
    private var timeLeft = 30000L // 30 seconds per question
    private var questionsAnswered = 0
    private var correctAnswers = 0
    private lateinit var databaseHelper: DatabaseHelper
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)
        
        initializeViews()
        databaseHelper = DatabaseHelper(this)
        loadQuestions()
        setupClickListeners()
        displayQuestion()
        startTimer()
    }
    
    private fun initializeViews() {
        questionText = findViewById(R.id.questionText)
        questionNumberText = findViewById(R.id.questionNumberText)
        scoreText = findViewById(R.id.scoreText)
        timerText = findViewById(R.id.timerText)
        categoryText = findViewById(R.id.categoryText)
        difficultyText = findViewById(R.id.difficultyText)
        hintButton = findViewById(R.id.hintButton)
        progressBar = findViewById(R.id.progressBar)
        
        optionButtons = listOf(
            findViewById(R.id.option1Button),
            findViewById(R.id.option2Button),
            findViewById(R.id.option3Button),
            findViewById(R.id.option4Button)
        )
    }
    
    private fun loadQuestions() {
        questions = QuizData.generateAllQuestions().shuffled()
    }
    
    private fun setupClickListeners() {
        optionButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                selectAnswer(index)
            }
        }
        
        hintButton.setOnClickListener {
            showHint()
        }
    }
    
    private fun displayQuestion() {
        if (currentQuestionIndex >= questions.size) {
            endQuiz()
            return
        }
        
        val question = questions[currentQuestionIndex]
        
        questionText.text = question.question
        questionNumberText.text = "Question ${currentQuestionIndex + 1} of ${questions.size}"
        categoryText.text = "Category: ${question.category}"
        difficultyText.text = "Difficulty: ${question.difficulty}"
        
        optionButtons.forEachIndexed { index, button ->
            if (index < question.options.size) {
                button.text = question.options[index]
                button.isEnabled = true
                button.alpha = 1.0f
            }
        }
        
        hintButton.isEnabled = question.hint != null
        hintButton.alpha = if (question.hint != null) 1.0f else 0.5f
        
        progressBar.progress = ((currentQuestionIndex + 1) * 100) / questions.size
    }
    
    private fun selectAnswer(selectedIndex: Int) {
        val question = questions[currentQuestionIndex]
        val isCorrect = selectedIndex == question.correctAnswer
        
        if (isCorrect) {
            score += when (question.difficulty) {
                "EASY" -> 10
                "MEDIUM" -> 25
                "HARD" -> 50
                "EXPERT" -> 100
                else -> 10
            }
            correctAnswers++
        }
        
        questionsAnswered++
        
        // Disable all buttons
        optionButtons.forEach { it.isEnabled = false }
        
        // Highlight correct answer in green
        optionButtons[question.correctAnswer].setBackgroundColor(getColor(android.R.color.holo_green_light))
        
        // Highlight selected answer in red if wrong
        if (!isCorrect) {
            optionButtons[selectedIndex].setBackgroundColor(getColor(android.R.color.holo_red_light))
        }
        
        updateScore()
        
        // Move to next question after delay
        timer?.cancel()
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            currentQuestionIndex++
            resetButtonColors()
            displayQuestion()
            startTimer()
        }, 2000)
    }
    
    private fun resetButtonColors() {
        optionButtons.forEach { button ->
            button.setBackgroundColor(getColor(android.R.color.white))
        }
    }
    
    private fun showHint() {
        val question = questions[currentQuestionIndex]
        if (question.hint != null) {
            AlertDialog.Builder(this)
                .setTitle("Hint")
                .setMessage(question.hint)
                .setPositiveButton("OK", null)
                .show()
        }
    }
    
    private fun showFlagCollected(flag: String) {
        AlertDialog.Builder(this)
            .setTitle("🏆 Flag Captured!")
            .setMessage("You found a flag!\n\n$flag")
            .setPositiveButton("Awesome!", null)
            .setIcon(android.R.drawable.ic_dialog_info)
            .show()
    }
    
    private fun startTimer() {
        timer?.cancel()
        timeLeft = 30000L
        timer = object : CountDownTimer(timeLeft, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timeLeft = millisUntilFinished
                val seconds = (millisUntilFinished / 1000).toInt()
                timerText.text = "Time: ${seconds}s"
            }
            
            override fun onFinish() {
                // Time's up - move to next question
                currentQuestionIndex++
                displayQuestion()
                startTimer()
            }
        }.start()
    }
    
    private fun updateScore() {
        scoreText.text = "Score: $score"
    }
    
    private fun endQuiz() {
        timer?.cancel()
        
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val highScore = prefs.getInt("high_score", 0)
        
        if (score > highScore) {
            prefs.edit().putInt("high_score", score).apply()
        }
        
        // Quiz completed - no flags to collect
        
        val intent = Intent(this, ScoreActivity::class.java).apply {
            putExtra("score", score)
            putExtra("total_questions", questionsAnswered)
            putExtra("correct_answers", correctAnswers)
            putExtra("is_new_high_score", score > highScore)
        }
        
        startActivity(intent)
        finish()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}
