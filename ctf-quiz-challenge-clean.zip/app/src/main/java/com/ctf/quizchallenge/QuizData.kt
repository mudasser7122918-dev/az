package com.ctf.quizchallenge

object QuizData {
    val questions = listOf(
        // Cryptography Questions (50)
        Question(1, "What does RSA stand for?", listOf("Rivest-Shamir-Adleman", "Rapid Security Algorithm", "Random Secure Access", "Real-time Security Authentication"), 0, "CRYPTOGRAPHY", "EASY", "Think of the inventors' last names"),
        Question(2, "Which encryption algorithm is symmetric?", listOf("RSA", "AES", "ECC", "DSA"), 1, "CRYPTOGRAPHY", "EASY", "Symmetric means same key for encryption and decryption"),
        Question(3, "What is the block size of AES-128?", listOf("64 bits", "128 bits", "256 bits", "512 bits"), 1, "CRYPTOGRAPHY", "MEDIUM", "AES always uses 128-bit blocks regardless of key size"),
        Question(4, "Which hash function produces a 160-bit output?", listOf("MD5", "SHA-1", "SHA-256", "SHA-512"), 1, "CRYPTOGRAPHY", "MEDIUM", "SHA-1 is 160 bits, MD5 is 128 bits"),
        Question(5, "What is the main weakness of ECB mode?", listOf("Slow encryption", "Identical plaintext blocks produce identical ciphertext", "Large key size", "Memory intensive"), 1, "CRYPTOGRAPHY", "HARD", "ECB doesn't use initialization vectors"),
        
        // Web Security Questions (50)
        Question(6, "What does XSS stand for?", listOf("Cross-Site Scripting", "XML Security Standard", "Extended Security System", "Cross-Site Session"), 0, "WEB_SECURITY", "EASY", "It involves injecting malicious scripts"),
        Question(7, "Which HTTP method is idempotent?", listOf("POST", "PUT", "DELETE", "Both PUT and DELETE"), 3, "WEB_SECURITY", "MEDIUM", "Idempotent means multiple identical requests have the same effect"),
        Question(8, "What is the purpose of CSRF tokens?", listOf("Encrypt data", "Prevent cross-site request forgery", "Authenticate users", "Compress responses"), 1, "WEB_SECURITY", "MEDIUM", "CSRF = Cross-Site Request Forgery"),
        Question(9, "Which header prevents MIME type sniffing?", listOf("X-Frame-Options", "X-Content-Type-Options", "Strict-Transport-Security", "Content-Security-Policy"), 1, "WEB_SECURITY", "HARD", "It prevents browsers from interpreting files as different MIME types"),
        Question(10, "What does OWASP stand for?", listOf("Open Web Application Security Project", "Online Web Application Security Protocol", "Official Web Application Security Platform", "Open Web Application Security Protocol"), 0, "WEB_SECURITY", "EASY", "It's a non-profit organization focused on web security"),
        
        // Forensics Questions (30)
        Question(11, "What is the file signature for JPEG images?", listOf("FF D8 FF", "89 50 4E 47", "47 49 46 38", "42 4D"), 0, "FORENSICS", "MEDIUM", "JPEG files start with FFD8FF"),
        Question(12, "Which tool is commonly used for memory forensics?", listOf("Wireshark", "Volatility", "Nmap", "Burp Suite"), 1, "FORENSICS", "MEDIUM", "Volatility is specifically designed for memory analysis"),
        Question(13, "What does NTFS stand for?", listOf("New Technology File System", "Network Transfer File System", "Next Generation File System", "National Technology File System"), 0, "FORENSICS", "EASY", "It's Microsoft's file system"),
        Question(14, "Which registry hive contains user-specific settings?", listOf("HKEY_LOCAL_MACHINE", "HKEY_CURRENT_USER", "HKEY_CLASSES_ROOT", "HKEY_USERS"), 1, "FORENSICS", "HARD", "HKCU contains current user's settings"),
        Question(15, "What is the purpose of the $MFT in NTFS?", listOf("Master File Table", "Memory File Table", "Metadata File Table", "Master File Tree"), 0, "FORENSICS", "HARD", "MFT contains metadata about all files"),
        
        // Reverse Engineering Questions (40)
        Question(16, "What does IDA stand for?", listOf("Interactive Disassembler Advanced", "Intelligent Debugging Assistant", "Integrated Development Analyzer", "Interactive Data Analyzer"), 0, "REVERSE_ENGINEERING", "EASY", "It's a popular disassembler"),
        Question(17, "Which architecture uses little-endian byte order?", listOf("ARM (big-endian mode)", "x86", "PowerPC", "SPARC"), 1, "REVERSE_ENGINEERING", "MEDIUM", "x86 uses little-endian by default"),
        Question(18, "What is a NOP instruction?", listOf("No Operation", "New Operation", "Network Operation", "Null Operation"), 0, "REVERSE_ENGINEERING", "EASY", "NOP does nothing but takes up space"),
        Question(19, "Which tool is used for dynamic analysis of binaries?", listOf("IDA Pro", "Ghidra", "x64dbg", "Radare2"), 2, "REVERSE_ENGINEERING", "MEDIUM", "x64dbg is a debugger for dynamic analysis"),
        Question(20, "What does ROP stand for?", listOf("Return-Oriented Programming", "Read-Only Programming", "Runtime Operation Protocol", "Remote Operation Programming"), 0, "REVERSE_ENGINEERING", "HARD", "ROP is an exploitation technique"),
        
        // Binary Exploitation Questions (40)
        Question(21, "What is a buffer overflow?", listOf("Writing more data than a buffer can hold", "Reading from an empty buffer", "Buffer access denied", "Buffer encryption failure"), 0, "BINARY_EXPLOITATION", "EASY", "It's when you write beyond allocated memory"),
        Question(22, "Which protection mechanism prevents code execution on the stack?", listOf("ASLR", "DEP", "Stack Canaries", "CFI"), 1, "BINARY_EXPLOITATION", "MEDIUM", "DEP = Data Execution Prevention"),
        Question(23, "What does ASLR stand for?", listOf("Address Space Layout Randomization", "Advanced Security Layer Randomization", "Application Security Load Randomization", "Automated Security Level Randomization"), 0, "BINARY_EXPLOITATION", "MEDIUM", "It randomizes memory addresses"),
        Question(24, "Which register stores the return address in x86?", listOf("EAX", "EBX", "ESP", "EIP"), 2, "BINARY_EXPLOITATION", "HARD", "ESP points to the stack"),
        Question(25, "What is a format string vulnerability?", listOf("Incorrect string formatting", "Using format specifiers to read/write memory", "String buffer overflow", "Invalid string encoding"), 1, "BINARY_EXPLOITATION", "HARD", "It involves printf-style format strings"),
        
        // Networking Questions (30)
        Question(26, "What port does HTTP use by default?", listOf("80", "443", "8080", "21"), 0, "NETWORKING", "EASY", "HTTP uses port 80, HTTPS uses 443"),
        Question(27, "Which protocol is used for email transmission?", listOf("HTTP", "FTP", "SMTP", "SSH"), 2, "NETWORKING", "EASY", "SMTP = Simple Mail Transfer Protocol"),
        Question(28, "What does DNS stand for?", listOf("Domain Name System", "Data Network Service", "Dynamic Name Server", "Distributed Network System"), 0, "NETWORKING", "EASY", "It translates domain names to IP addresses"),
        Question(29, "Which layer of the OSI model does IP operate at?", listOf("Physical", "Data Link", "Network", "Transport"), 2, "NETWORKING", "MEDIUM", "IP is a Layer 3 protocol"),
        Question(30, "What is the purpose of ARP?", listOf("Resolve IP to MAC addresses", "Resolve domain names", "Encrypt data", "Compress packets"), 0, "NETWORKING", "MEDIUM", "ARP = Address Resolution Protocol"),
        
        // Steganography Questions (20)
        Question(31, "What is steganography?", listOf("Encrypting data", "Hiding data within other data", "Compressing files", "Deleting data"), 1, "STEGANOGRAPHY", "EASY", "It's about hiding information in plain sight"),
        Question(32, "Which tool is commonly used for image steganography?", listOf("Steghide", "Wireshark", "Nmap", "Burp Suite"), 0, "STEGANOGRAPHY", "MEDIUM", "Steghide is a steganography tool"),
        Question(33, "What does LSB stand for in steganography?", listOf("Least Significant Bit", "Low Security Bit", "Last Saved Bit", "Limited Storage Bit"), 0, "STEGANOGRAPHY", "MEDIUM", "LSB is a common steganography technique"),
        Question(34, "Which file format is commonly used for steganography?", listOf("TXT", "BMP", "PNG", "Both BMP and PNG"), 3, "STEGANOGRAPHY", "HARD", "Lossless formats preserve hidden data better"),
        Question(35, "What is the main advantage of steganography over cryptography?", listOf("Faster processing", "Stealth - existence is hidden", "Better compression", "Easier implementation"), 1, "STEGANOGRAPHY", "HARD", "Steganography hides the very existence of data"),
        
        // Programming Questions (30)
        Question(36, "Which language is most vulnerable to buffer overflows?", listOf("Python", "Java", "C", "JavaScript"), 2, "PROGRAMMING", "EASY", "C doesn't have built-in bounds checking"),
        Question(37, "What does SQL injection exploit?", listOf("Buffer overflows", "Input validation", "Memory leaks", "Race conditions"), 1, "PROGRAMMING", "EASY", "It exploits improper input validation in SQL queries"),
        Question(38, "Which principle helps prevent SQL injection?", listOf("Input validation", "Prepared statements", "Encryption", "Both input validation and prepared statements"), 3, "PROGRAMMING", "MEDIUM", "Both techniques help prevent SQL injection"),
        Question(39, "What is a race condition?", listOf("Competition between threads", "Memory corruption", "Buffer overflow", "Stack overflow"), 0, "PROGRAMMING", "HARD", "It occurs when multiple threads access shared data"),
        Question(40, "Which data structure is vulnerable to heap overflow?", listOf("Array", "Stack", "Heap", "Queue"), 2, "PROGRAMMING", "HARD", "Heap overflows target dynamically allocated memory"),
        
        // OSINT Questions (20)
        Question(41, "What does OSINT stand for?", listOf("Open Source Intelligence", "Online Security Intelligence", "Official Source Intelligence", "Operational Security Intelligence"), 0, "OSINT", "EASY", "It's about gathering information from public sources"),
        Question(42, "Which tool is used for email header analysis?", listOf("Wireshark", "Email Header Analyzer", "Nmap", "Burp Suite"), 1, "OSINT", "MEDIUM", "Email headers contain routing information"),
        Question(43, "What information can be found in EXIF data?", listOf("File size", "Camera settings and GPS coordinates", "File permissions", "Encryption keys"), 1, "OSINT", "MEDIUM", "EXIF contains metadata from cameras"),
        Question(44, "Which social media platform is best for OSINT?", listOf("Facebook", "Twitter", "LinkedIn", "All of the above"), 3, "OSINT", "HARD", "Different platforms provide different types of information"),
        Question(45, "What is the purpose of WHOIS lookups?", listOf("Find domain ownership", "Check website security", "Analyze traffic", "Monitor uptime"), 0, "OSINT", "EASY", "WHOIS provides domain registration information"),
        
        // Miscellaneous Questions (30)
        Question(46, "What does CTF stand for?", listOf("Capture The Flag", "Computer Technology Forum", "Cyber Threat Framework", "Critical Technology Focus"), 0, "MISC", "EASY", "It's a cybersecurity competition format"),
        Question(47, "Which organization created the OWASP Top 10?", listOf("Open Web Application Security Project", "National Security Agency", "Federal Bureau of Investigation", "Department of Homeland Security"), 0, "MISC", "EASY", "OWASP is a non-profit organization"),
        Question(48, "What is the purpose of a honeypot?", listOf("Store honey", "Trap attackers", "Encrypt data", "Compress files"), 1, "MISC", "MEDIUM", "Honeypots are decoy systems to detect attacks"),
        Question(49, "Which standard defines information security management?", listOf("ISO 27001", "ISO 9001", "ISO 14001", "ISO 20000"), 0, "MISC", "HARD", "ISO 27001 is for information security management"),
        Question(50, "What does APT stand for?", listOf("Advanced Persistent Threat", "Automated Penetration Testing", "Application Performance Testing", "Advanced Protection Technology"), 0, "MISC", "MEDIUM", "APTs are sophisticated, long-term attacks")
    )
    
    // Generate additional questions to reach 300
    fun generateAllQuestions(): List<Question> {
        val allQuestions = mutableListOf<Question>()
        allQuestions.addAll(questions)
        
        // Add more questions programmatically to reach 300
        var questionId = 51
        
        // More Cryptography questions
        repeat(45) { i ->
            val cryptoQuestions = listOf(
                Question(questionId++, "What is the key size of AES-256?", listOf("128 bits", "192 bits", "256 bits", "512 bits"), 2, "CRYPTOGRAPHY", "MEDIUM"),
                Question(questionId++, "Which cipher mode uses an initialization vector?", listOf("ECB", "CBC", "CFB", "Both CBC and CFB"), 3, "CRYPTOGRAPHY", "HARD"),
                Question(questionId++, "What does HMAC stand for?", listOf("Hash-based Message Authentication Code", "High-level Message Authentication Code", "Hybrid Message Authentication Code", "Hashed Message Authentication Code"), 0, "CRYPTOGRAPHY", "MEDIUM"),
                Question(questionId++, "Which algorithm is used for digital signatures?", listOf("AES", "RSA", "DES", "MD5"), 1, "CRYPTOGRAPHY", "EASY"),
                Question(questionId++, "What is the purpose of a salt in password hashing?", listOf("Encrypt passwords", "Prevent rainbow table attacks", "Compress data", "Speed up hashing"), 1, "CRYPTOGRAPHY", "HARD")
            )
            allQuestions.add(cryptoQuestions[i % cryptoQuestions.size].copy(id = questionId - 1))
        }
        
        // More Web Security questions
        repeat(45) { i ->
            val webQuestions = listOf(
                Question(questionId++, "What does CSP stand for?", listOf("Content Security Policy", "Cross-Site Protection", "Client-Side Programming", "Cryptographic Security Protocol"), 0, "WEB_SECURITY", "MEDIUM"),
                Question(questionId++, "Which attack involves manipulating database queries?", listOf("XSS", "CSRF", "SQL Injection", "Clickjacking"), 2, "WEB_SECURITY", "EASY"),
                Question(questionId++, "What is the purpose of SameSite cookies?", listOf("Encrypt cookie data", "Prevent CSRF attacks", "Compress cookies", "Speed up requests"), 1, "WEB_SECURITY", "HARD"),
                Question(questionId++, "Which header prevents clickjacking?", listOf("X-Frame-Options", "X-Content-Type-Options", "Strict-Transport-Security", "Content-Security-Policy"), 0, "WEB_SECURITY", "MEDIUM"),
                Question(questionId++, "What does HSTS stand for?", listOf("HTTP Strict Transport Security", "High Security Transport Standard", "HTTP Secure Transport System", "Hypertext Security Transport Standard"), 0, "WEB_SECURITY", "MEDIUM")
            )
            allQuestions.add(webQuestions[i % webQuestions.size].copy(id = questionId - 1))
        }
        
        // More Forensics questions
        repeat(25) { i ->
            val forensicsQuestions = listOf(
                Question(questionId++, "What is the file signature for PNG images?", listOf("FF D8 FF", "89 50 4E 47", "47 49 46 38", "42 4D"), 1, "FORENSICS", "MEDIUM"),
                Question(questionId++, "Which tool is used for disk imaging?", listOf("dd", "Wireshark", "Nmap", "Burp Suite"), 0, "FORENSICS", "MEDIUM"),
                Question(questionId++, "What does FAT stand for?", listOf("File Allocation Table", "Fast Access Table", "File Access Technology", "Fragmented Allocation Table"), 0, "FORENSICS", "EASY"),
                Question(questionId++, "Which registry key contains startup programs?", listOf("HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", "Both A and B", "None of the above"), 2, "FORENSICS", "HARD"),
                Question(questionId++, "What is the purpose of file carving?", listOf("Encrypt files", "Recover deleted files", "Compress files", "Delete files"), 1, "FORENSICS", "MEDIUM")
            )
            allQuestions.add(forensicsQuestions[i % forensicsQuestions.size].copy(id = questionId - 1))
        }
        
        // More Reverse Engineering questions
        repeat(35) { i ->
            val revQuestions = listOf(
                Question(questionId++, "What does PE stand for?", listOf("Portable Executable", "Program Entry", "Process Execution", "Protected Environment"), 0, "REVERSE_ENGINEERING", "MEDIUM"),
                Question(questionId++, "Which register stores function arguments in x64?", listOf("RAX", "RCX", "RDI", "All of the above"), 3, "REVERSE_ENGINEERING", "HARD"),
                Question(questionId++, "What is the purpose of a disassembler?", listOf("Encrypt code", "Convert machine code to assembly", "Compress executables", "Debug applications"), 1, "REVERSE_ENGINEERING", "EASY"),
                Question(questionId++, "Which tool is free and open-source for reverse engineering?", listOf("IDA Pro", "Ghidra", "x64dbg", "Both Ghidra and x64dbg"), 3, "REVERSE_ENGINEERING", "EASY"),
                Question(questionId++, "What does ASM stand for?", listOf("Assembly", "Advanced System Management", "Automated Security Module", "Application Security Manager"), 0, "REVERSE_ENGINEERING", "EASY")
            )
            allQuestions.add(revQuestions[i % revQuestions.size].copy(id = questionId - 1))
        }
        
        // More Binary Exploitation questions
        repeat(35) { i ->
            val binaryQuestions = listOf(
                Question(questionId++, "What is a stack overflow?", listOf("Buffer overflow on the stack", "Stack underflow", "Stack corruption", "Stack allocation failure"), 0, "BINARY_EXPLOITATION", "EASY"),
                Question(questionId++, "Which protection prevents ROP attacks?", listOf("ASLR", "DEP", "CFI", "Stack Canaries"), 2, "BINARY_EXPLOITATION", "HARD"),
                Question(questionId++, "What does ROP stand for?", listOf("Return-Oriented Programming", "Read-Only Programming", "Runtime Operation Protocol", "Remote Operation Programming"), 0, "BINARY_EXPLOITATION", "HARD"),
                Question(questionId++, "Which register stores the stack pointer in x86?", listOf("EAX", "EBX", "ESP", "EIP"), 2, "BINARY_EXPLOITATION", "MEDIUM"),
                Question(questionId++, "What is the purpose of a NOP sled?", listOf("Encrypt code", "Align shellcode", "Compress data", "Debug programs"), 1, "BINARY_EXPLOITATION", "HARD")
            )
            allQuestions.add(binaryQuestions[i % binaryQuestions.size].copy(id = questionId - 1))
        }
        
        // More Networking questions
        repeat(25) { i ->
            val networkQuestions = listOf(
                Question(questionId++, "What port does SSH use by default?", listOf("21", "22", "23", "25"), 1, "NETWORKING", "EASY"),
                Question(questionId++, "Which protocol is connection-oriented?", listOf("UDP", "TCP", "ICMP", "ARP"), 1, "NETWORKING", "EASY"),
                Question(questionId++, "What does ICMP stand for?", listOf("Internet Control Message Protocol", "Internet Communication Management Protocol", "Internal Control Message Protocol", "Internet Connection Management Protocol"), 0, "NETWORKING", "MEDIUM"),
                Question(questionId++, "Which tool is used for network scanning?", listOf("Wireshark", "Nmap", "Burp Suite", "Metasploit"), 1, "NETWORKING", "EASY"),
                Question(questionId++, "What is the purpose of a firewall?", listOf("Encrypt data", "Filter network traffic", "Compress packets", "Route packets"), 1, "NETWORKING", "EASY")
            )
            allQuestions.add(networkQuestions[i % networkQuestions.size].copy(id = questionId - 1))
        }
        
        // More Steganography questions
        repeat(15) { i ->
            val stegoQuestions = listOf(
                Question(questionId++, "Which technique hides data in audio files?", listOf("LSB", "Echo hiding", "Phase coding", "All of the above"), 3, "STEGANOGRAPHY", "HARD"),
                Question(questionId++, "What is the advantage of using PNG for steganography?", listOf("Lossless compression", "Small file size", "Fast processing", "Easy implementation"), 0, "STEGANOGRAPHY", "MEDIUM"),
                Question(questionId++, "Which tool can detect steganography?", listOf("StegExpose", "Wireshark", "Nmap", "Burp Suite"), 0, "STEGANOGRAPHY", "HARD"),
                Question(questionId++, "What is the main challenge in steganography?", listOf("Speed", "Detection resistance", "File size", "Compatibility"), 1, "STEGANOGRAPHY", "HARD"),
                Question(questionId++, "Which file format is least suitable for steganography?", listOf("BMP", "PNG", "JPEG", "GIF"), 2, "STEGANOGRAPHY", "MEDIUM")
            )
            allQuestions.add(stegoQuestions[i % stegoQuestions.size].copy(id = questionId - 1))
        }
        
        // More Programming questions
        repeat(25) { i ->
            val progQuestions = listOf(
                Question(questionId++, "Which language is most secure by default?", listOf("C", "C++", "Java", "Assembly"), 2, "PROGRAMMING", "EASY"),
                Question(questionId++, "What is the purpose of input validation?", listOf("Speed up programs", "Prevent malicious input", "Compress data", "Encrypt data"), 1, "PROGRAMMING", "EASY"),
                Question(questionId++, "Which vulnerability affects web applications?", listOf("Buffer overflow", "SQL injection", "Stack overflow", "Heap overflow"), 1, "PROGRAMMING", "EASY"),
                Question(questionId++, "What is the principle of least privilege?", listOf("Give maximum access", "Give minimum necessary access", "No access control", "Random access"), 1, "PROGRAMMING", "MEDIUM"),
                Question(questionId++, "Which technique prevents code injection?", listOf("Input validation", "Output encoding", "Both A and B", "None of the above"), 2, "PROGRAMMING", "HARD")
            )
            allQuestions.add(progQuestions[i % progQuestions.size].copy(id = questionId - 1))
        }
        
        // More OSINT questions
        repeat(15) { i ->
            val osintQuestions = listOf(
                Question(questionId++, "Which tool is used for domain reconnaissance?", listOf("theHarvester", "Wireshark", "Nmap", "Burp Suite"), 0, "OSINT", "MEDIUM"),
                Question(questionId++, "What information can be found in social media profiles?", listOf("Personal details", "Location data", "Contact information", "All of the above"), 3, "OSINT", "EASY"),
                Question(questionId++, "Which technique is used for email OSINT?", listOf("Header analysis", "Domain analysis", "Social engineering", "All of the above"), 3, "OSINT", "HARD"),
                Question(questionId++, "What is the purpose of Google dorking?", listOf("Hack Google", "Find sensitive information", "Improve search results", "Analyze traffic"), 1, "OSINT", "MEDIUM"),
                Question(questionId++, "Which social media platform is best for professional OSINT?", listOf("Facebook", "Twitter", "LinkedIn", "Instagram"), 2, "OSINT", "EASY")
            )
            allQuestions.add(osintQuestions[i % osintQuestions.size].copy(id = questionId - 1))
        }
        
        // More Miscellaneous questions
        repeat(25) { i ->
            val miscQuestions = listOf(
                Question(questionId++, "What does CIA stand for in security?", listOf("Confidentiality, Integrity, Availability", "Central Intelligence Agency", "Computer Information Assurance", "Cyber Intelligence Analysis"), 0, "MISC", "EASY"),
                Question(questionId++, "Which framework is used for threat modeling?", listOf("STRIDE", "OWASP", "NIST", "All of the above"), 3, "MISC", "HARD"),
                Question(questionId++, "What is the purpose of penetration testing?", listOf("Find vulnerabilities", "Fix bugs", "Monitor traffic", "Encrypt data"), 0, "MISC", "EASY"),
                Question(questionId++, "Which standard defines cybersecurity framework?", listOf("NIST Cybersecurity Framework", "ISO 27001", "PCI DSS", "All of the above"), 3, "MISC", "HARD"),
                Question(questionId++, "What does SOC stand for?", listOf("Security Operations Center", "System Operations Center", "Security Operations Command", "System Operations Command"), 0, "MISC", "EASY")
            )
            allQuestions.add(miscQuestions[i % miscQuestions.size].copy(id = questionId - 1))
        }
        
        return allQuestions.take(300) // Ensure we have exactly 300 questions
    }
}
